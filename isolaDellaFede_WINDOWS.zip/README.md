# l'isola-della-fede
School project

Finito:

Menu iniziale, Impostazioni. (Non ancora aggiunto tutte le opzioni che si possono modificare)
27/12/2025
Abbiamo riscritto il codice usando le librerie studiate più Windows.h perchè altrimenti non saremmo riusciti a mettere il titolo ASCII con i colori.
